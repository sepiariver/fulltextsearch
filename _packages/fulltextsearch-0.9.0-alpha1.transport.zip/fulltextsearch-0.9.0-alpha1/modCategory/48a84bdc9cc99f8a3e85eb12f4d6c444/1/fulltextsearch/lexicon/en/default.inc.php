<?php

$_lang['fulltextsearch']                    = 'FullTextSearch';
$_lang['fulltextsearch.menu_desc']          = 'Re-index FTS';