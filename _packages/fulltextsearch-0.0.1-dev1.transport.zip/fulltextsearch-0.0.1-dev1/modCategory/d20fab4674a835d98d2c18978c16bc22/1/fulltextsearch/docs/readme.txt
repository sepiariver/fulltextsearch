# FullTextSearch
MySQL FULLTEXT search for MODX CMS.
