<?php
/**
 * @package fulltextsearch
 */
class FTSContent extends xPDOSimpleObject {}
?>